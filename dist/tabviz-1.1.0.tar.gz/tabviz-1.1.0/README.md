# Tabviz

TabViz is a [pip library](https://pypi.org/project/tabviz/) which simplifies the process of creating interactive data visualization in your jupyter notebook automatically using tableau and Gen-AI, all you have to do is provide a dataset(in csv)  and wait for TabViz to generate you a useful enough visualization.  

## Key Features
