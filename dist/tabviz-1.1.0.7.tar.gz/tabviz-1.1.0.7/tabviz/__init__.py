from starlette import status as status

from .tabvizmain import main


if __name__ == "__main__":
    main()